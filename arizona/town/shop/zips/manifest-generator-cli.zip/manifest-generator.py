#!/usr/bin/env python3
import os, json, argparse, time
TYPE_BY_EXT={'.pdf':'pdf','.png':'image','.jpg':'image','.jpeg':'image','.gif':'image','.webp':'image','.svg':'image','.mp4':'video','.webm':'video','.mov':'video','.mkv':'video','.mp3':'audio','.ogg':'audio','.wav':'audio','.flac':'audio','.m4a':'audio','.zip':'zip','.7z':'zip','.rar':'zip','.tar':'zip','.gz':'zip','.xz':'zip','.md':'md','.markdown':'md','.txt':'md','.rtf':'md','.html':'other','.htm':'other','.js':'script','.ts':'script','.py':'script','.sh':'script'}
def infer_type(p): return TYPE_BY_EXT.get(os.path.splitext(p)[1].lower(),'other')
def rel(base, p): return os.path.relpath(p, base).replace('\\','/')
def main():
  ap=argparse.ArgumentParser(description='Génère un manifest.json à partir d’un dossier.')
  ap.add_argument('root', nargs='?', default='.', help='Dossier racine (par défaut: .)')
  ap.add_argument('-o','--output', default='manifest.json', help='Fichier de sortie')
  args=ap.parse_args()
  root=os.path.abspath(args.root); items=[]
  for r,_,files in os.walk(root):
    for f in files:
      p=os.path.join(r,f); rp=rel(root,p)
      if os.path.basename(p).startswith('.'): continue
      if rp.startswith(('css/','md/','schema/','scripts/','thumbs/','zips/')): continue
      t=infer_type(p)
      if t=='other' and not os.path.splitext(p)[1]: 
        continue
      st=os.stat(p)
      item={
        "id": os.path.splitext(os.path.basename(p))[0],
        "title": os.path.basename(p),
        "url": "./"+rp,
        "type": t,
        "size": st.st_size,
        "tags": [t, os.path.splitext(p)[1].lower().lstrip('.')],
        "created": time.strftime('%Y-%m-%d', time.localtime(st.st_mtime))
      }
      items.append(item)
  man={"items": items}
  with open(args.output,'w',encoding='utf-8') as f: json.dump(man,f,indent=2,ensure_ascii=False)
  print(f"Écrit {args.output} avec {len(items)} items.")
if __name__=='__main__': main()
